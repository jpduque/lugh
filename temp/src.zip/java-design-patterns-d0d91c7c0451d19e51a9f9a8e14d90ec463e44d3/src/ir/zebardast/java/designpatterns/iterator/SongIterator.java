package ir.zebardast.java.designpatterns.iterator;

import java.util.Iterator;

public interface SongIterator {

    public Iterator createIterator();

}